import { peso } from "@/lib/shop/format";

export function CartTable({ items }: { items: any[] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-black/10 bg-white text-black">
      <table className="w-full text-left text-sm">
        <thead className="bg-zinc-100">
          <tr>
            <th className="px-4 py-3">Product</th>
            <th className="px-4 py-3">Qty</th>
            <th className="px-4 py-3">Price</th>
            <th className="px-4 py-3">Total</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} className="border-t border-zinc-200">
              <td className="px-4 py-3">{item.product.name}</td>
              <td className="px-4 py-3">{item.quantity}</td>
              <td className="px-4 py-3">{peso(Number(item.product.price))}</td>
              <td className="px-4 py-3">{peso(Number(item.product.price) * item.quantity)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
