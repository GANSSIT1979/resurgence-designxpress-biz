import Link from "next/link";

export function ShopLayout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link href="/shop" className="text-2xl font-bold tracking-wide">RESURGENCE SHOP</Link>
          <nav className="flex gap-5 text-sm text-white/80">
            <Link href="/shop">Shop</Link>
            <Link href="/cart">Cart</Link>
            <Link href="/account/orders">Orders</Link>
            <Link href="/admin/products">Admin Products</Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-6 py-8">
        <h1 className="mb-6 text-3xl font-semibold">{title}</h1>
        {children}
      </main>
    </div>
  );
}
