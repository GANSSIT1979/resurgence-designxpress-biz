import Link from "next/link";
import { peso } from "@/lib/shop/format";

export function ProductCard({ product }: { product: any }) {
  return (
    <div className="rounded-2xl border border-black/10 bg-white p-4 text-black shadow-sm">
      <div className="aspect-square rounded-xl bg-zinc-100" />
      <div className="mt-4 space-y-2">
        <div className="text-lg font-semibold">{product.name}</div>
        <div className="text-sm text-zinc-500">{product.shortDescription || product.description}</div>
        <div className="font-bold text-rose-600">{peso(Number(product.price))}</div>
        <div className="flex gap-2">
          <Link className="rounded-lg bg-black px-3 py-2 text-sm text-white" href={`/shop/product/${product.slug}`}>View</Link>
          <form action="/api/cart" method="post">
            <input type="hidden" name="productId" value={product.id} />
            <button className="rounded-lg bg-rose-600 px-3 py-2 text-sm text-white" type="submit">Add to Cart</button>
          </form>
        </div>
      </div>
    </div>
  );
}
