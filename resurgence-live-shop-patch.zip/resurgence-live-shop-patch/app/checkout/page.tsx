import { getCart } from '@/lib/shop/cart';
import { ShopLayout } from '@/components/shop/ShopLayout';
import { peso } from '@/lib/shop/format';

export default async function CheckoutPage() {
  const cart = await getCart();
  return (
    <ShopLayout title="Checkout">
      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <form action="/api/checkout" method="post" className="space-y-4 rounded-2xl bg-white p-6 text-black">
          <div className="grid gap-4 md:grid-cols-2">
            <input name="fullName" required placeholder="Full Name" className="rounded-xl border px-4 py-3" />
            <input name="phone" required placeholder="Phone" className="rounded-xl border px-4 py-3" />
          </div>
          <input name="line1" required placeholder="Address Line 1" className="w-full rounded-xl border px-4 py-3" />
          <input name="line2" placeholder="Address Line 2" className="w-full rounded-xl border px-4 py-3" />
          <div className="grid gap-4 md:grid-cols-3">
            <input name="city" required placeholder="City" className="rounded-xl border px-4 py-3" />
            <input name="province" required placeholder="Province" className="rounded-xl border px-4 py-3" />
            <input name="postalCode" placeholder="Postal Code" className="rounded-xl border px-4 py-3" />
          </div>
          <select name="paymentMethod" className="w-full rounded-xl border px-4 py-3">
            <option value="COD">Cash on Delivery</option>
            <option value="GCASH_MANUAL">GCash Manual</option>
            <option value="BANK_TRANSFER">Bank Transfer</option>
          </select>
          <textarea name="notes" placeholder="Order notes" className="min-h-28 w-full rounded-xl border px-4 py-3" />
          <button className="rounded-xl bg-rose-600 px-5 py-3 font-semibold text-white">Place order</button>
        </form>
        <div className="rounded-2xl bg-white p-6 text-black">
          <div className="mb-4 text-lg font-semibold">Order Summary</div>
          <div className="space-y-3 text-sm">
            {cart.items.map((item) => <div key={item.id} className="flex justify-between"><span>{item.product.name} × {item.quantity}</span><strong>{peso(Number(item.product.price) * item.quantity)}</strong></div>)}
            <div className="flex justify-between"><span>Shipping</span><strong>{peso(cart.shipping)}</strong></div>
            <div className="flex justify-between text-base"><span>Total</span><strong className="text-rose-600">{peso(cart.total)}</strong></div>
          </div>
        </div>
      </div>
    </ShopLayout>
  );
}
