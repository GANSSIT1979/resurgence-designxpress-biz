import { ShopLayout } from '@/components/shop/ShopLayout';
import { db, getShopUser } from '@/lib/shop/session';
import { peso } from '@/lib/shop/format';

export default async function OrdersPage() {
  const user = await getShopUser();
  const orders = await db.shopOrder.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } });
  return (
    <ShopLayout title="My Orders">
      <div className="overflow-hidden rounded-2xl bg-white text-black">
        <table className="w-full text-left text-sm">
          <thead className="bg-zinc-100"><tr><th className="px-4 py-3">Order</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Payment</th><th className="px-4 py-3">Total</th></tr></thead>
          <tbody>
            {orders.map((order) => <tr className="border-t" key={order.id}><td className="px-4 py-3">{order.orderNumber}</td><td className="px-4 py-3">{order.status}</td><td className="px-4 py-3">{order.paymentMethod}</td><td className="px-4 py-3">{peso(Number(order.totalAmount))}</td></tr>)}
          </tbody>
        </table>
      </div>
    </ShopLayout>
  );
}
