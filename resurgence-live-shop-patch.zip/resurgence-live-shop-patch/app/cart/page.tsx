import Link from 'next/link';
import { getCart } from '@/lib/shop/cart';
import { ShopLayout } from '@/components/shop/ShopLayout';
import { CartTable } from '@/components/shop/CartTable';
import { peso } from '@/lib/shop/format';

export default async function CartPage() {
  const cart = await getCart();
  return (
    <ShopLayout title="Your Cart">
      <div className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <CartTable items={cart.items} />
        <div className="rounded-2xl bg-white p-6 text-black">
          <div className="space-y-3 text-sm">
            <div className="flex justify-between"><span>Subtotal</span><strong>{peso(cart.subtotal)}</strong></div>
            <div className="flex justify-between"><span>Shipping</span><strong>{peso(cart.shipping)}</strong></div>
            <div className="flex justify-between text-base"><span>Total</span><strong className="text-rose-600">{peso(cart.total)}</strong></div>
          </div>
          <Link href="/checkout" className="mt-6 inline-block rounded-xl bg-rose-600 px-5 py-3 font-semibold text-white">Checkout</Link>
        </div>
      </div>
    </ShopLayout>
  );
}
