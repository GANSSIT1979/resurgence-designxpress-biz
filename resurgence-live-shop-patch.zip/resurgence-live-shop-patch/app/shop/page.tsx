import { db } from '@/lib/shop/session';
import { ShopLayout } from '@/components/shop/ShopLayout';
import { ProductCard } from '@/components/shop/ProductCard';

export default async function ShopPage() {
  const products = await db.shopProduct.findMany({ where: { active: true }, orderBy: [{ featured: 'desc' }, { createdAt: 'desc' }] });
  return (
    <ShopLayout title="Official Merch">
      <div className="mb-8 rounded-3xl bg-gradient-to-r from-zinc-900 to-black p-8">
        <div className="max-w-xl space-y-4">
          <div className="text-sm uppercase tracking-[0.2em] text-rose-400">Resurgence powered by DesignXpress</div>
          <div className="text-5xl font-black">Rise. Unite. Resurge.</div>
          <p className="text-white/70">Functional plug-and-play shop module integrated into the Resurgence full-stack platform.</p>
        </div>
      </div>
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {products.map((product) => <ProductCard key={product.id} product={product} />)}
      </div>
    </ShopLayout>
  );
}
