import { notFound } from 'next/navigation';
import { db } from '@/lib/shop/session';
import { ShopLayout } from '@/components/shop/ShopLayout';
import { peso } from '@/lib/shop/format';

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await db.shopProduct.findUnique({ where: { slug } });
  if (!product) return notFound();
  return (
    <ShopLayout title={product.name}>
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="aspect-square rounded-3xl bg-zinc-100" />
        <div className="space-y-4 rounded-3xl bg-white p-8 text-black">
          <div className="text-3xl font-bold">{product.name}</div>
          <div className="text-2xl font-extrabold text-rose-600">{peso(Number(product.price))}</div>
          <p className="text-zinc-600">{product.description}</p>
          <div className="text-sm text-zinc-500">Stock: {product.stock}</div>
          <form className="space-y-3" action="/api/cart" method="post">
            <input type="hidden" name="productId" value={product.id} />
            <input className="w-24 rounded-lg border px-3 py-2" type="number" min="1" defaultValue="1" name="quantity" />
            <button className="block rounded-xl bg-rose-600 px-5 py-3 font-semibold text-white" type="submit">Add to cart</button>
          </form>
        </div>
      </div>
    </ShopLayout>
  );
}
