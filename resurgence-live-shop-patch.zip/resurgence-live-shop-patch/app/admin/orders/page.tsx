import { ShopLayout } from '@/components/shop/ShopLayout';
import { db } from '@/lib/shop/session';
import { peso } from '@/lib/shop/format';

export default async function AdminOrdersPage() {
  const orders = await db.shopOrder.findMany({ include: { user: true }, orderBy: { createdAt: 'desc' } });
  return (
    <ShopLayout title="Admin Orders">
      <div className="overflow-hidden rounded-2xl bg-white text-black">
        <table className="w-full text-left text-sm">
          <thead className="bg-zinc-100"><tr><th className="px-4 py-3">Order</th><th className="px-4 py-3">Customer</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Payment</th><th className="px-4 py-3">Total</th></tr></thead>
          <tbody>{orders.map((order) => <tr className="border-t" key={order.id}><td className="px-4 py-3">{order.orderNumber}</td><td className="px-4 py-3">{order.user.name}</td><td className="px-4 py-3">{order.status}</td><td className="px-4 py-3">{order.paymentMethod}</td><td className="px-4 py-3">{peso(Number(order.totalAmount))}</td></tr>)}</tbody>
        </table>
      </div>
    </ShopLayout>
  );
}
