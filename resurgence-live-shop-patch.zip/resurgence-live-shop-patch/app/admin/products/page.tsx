import Link from 'next/link';
import { db } from '@/lib/shop/session';
import { ShopLayout } from '@/components/shop/ShopLayout';
import { peso } from '@/lib/shop/format';

export default async function AdminProductsPage() {
  const products = await db.shopProduct.findMany({ include: { category: true }, orderBy: { createdAt: 'desc' } });
  return (
    <ShopLayout title="Admin Products">
      <div className="mb-4 text-sm text-white/70">Direct commerce module added to the current Resurgence admin area.</div>
      <div className="overflow-hidden rounded-2xl bg-white text-black">
        <table className="w-full text-left text-sm">
          <thead className="bg-zinc-100"><tr><th className="px-4 py-3">Product</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Price</th><th className="px-4 py-3">Stock</th><th className="px-4 py-3">Status</th></tr></thead>
          <tbody>{products.map((product) => <tr className="border-t" key={product.id}><td className="px-4 py-3">{product.name}</td><td className="px-4 py-3">{product.category?.name || '-'}</td><td className="px-4 py-3">{peso(Number(product.price))}</td><td className="px-4 py-3">{product.stock}</td><td className="px-4 py-3">{product.active ? 'Active' : 'Inactive'}</td></tr>)}</tbody>
        </table>
      </div>
      <div className="mt-4 rounded-2xl bg-white p-6 text-black">
        <div className="mb-3 text-lg font-semibold">Quick add product</div>
        <form action="/api/admin/products" method="post" className="grid gap-3 md:grid-cols-2">
          <input name="name" className="rounded-xl border px-4 py-3" placeholder="Name" required />
          <input name="slug" className="rounded-xl border px-4 py-3" placeholder="Slug" required />
          <input name="price" type="number" className="rounded-xl border px-4 py-3" placeholder="Price" required />
          <input name="stock" type="number" className="rounded-xl border px-4 py-3" placeholder="Stock" required />
          <textarea name="description" className="md:col-span-2 rounded-xl border px-4 py-3" placeholder="Description" required />
          <button className="rounded-xl bg-rose-600 px-5 py-3 font-semibold text-white">Save product</button>
        </form>
      </div>
    </ShopLayout>
  );
}
