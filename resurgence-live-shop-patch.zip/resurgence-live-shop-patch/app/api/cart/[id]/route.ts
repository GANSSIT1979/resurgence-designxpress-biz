import { NextResponse } from 'next/server';
import { updateCartItem } from '@/lib/shop/cart';

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await request.json();
  const item = await updateCartItem(id, Number(body.quantity || 1));
  return NextResponse.json(item);
}
