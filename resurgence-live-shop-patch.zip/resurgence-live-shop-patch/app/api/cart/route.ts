import { NextResponse } from 'next/server';
import { addToCart, getCart } from '@/lib/shop/cart';

export async function GET() {
  return NextResponse.json(await getCart());
}

export async function POST(request: Request) {
  const contentType = request.headers.get('content-type') || '';
  let productId = '';
  let quantity = 1;
  if (contentType.includes('application/json')) {
    const body = await request.json();
    productId = body.productId;
    quantity = Number(body.quantity || 1);
  } else {
    const form = await request.formData();
    productId = String(form.get('productId') || '');
    quantity = Number(form.get('quantity') || 1);
  }
  await addToCart(productId, quantity);
  return NextResponse.redirect(new URL('/cart', request.url));
}
