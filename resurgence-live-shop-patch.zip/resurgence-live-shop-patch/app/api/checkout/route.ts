import { NextResponse } from 'next/server';
import { createOrder } from '@/lib/shop/checkout';

export async function POST(request: Request) {
  const form = await request.formData();
  const order = await createOrder({
    fullName: String(form.get('fullName') || ''),
    phone: String(form.get('phone') || ''),
    line1: String(form.get('line1') || ''),
    line2: String(form.get('line2') || ''),
    city: String(form.get('city') || ''),
    province: String(form.get('province') || ''),
    postalCode: String(form.get('postalCode') || ''),
    paymentMethod: String(form.get('paymentMethod') || 'COD') as any,
    notes: String(form.get('notes') || ''),
  });
  return NextResponse.redirect(new URL(`/account/orders`, request.url));
}
