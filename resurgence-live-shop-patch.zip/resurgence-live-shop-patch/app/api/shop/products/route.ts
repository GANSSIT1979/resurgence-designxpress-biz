import { NextResponse } from 'next/server';
import { db } from '@/lib/shop/session';

export async function GET() {
  const products = await db.shopProduct.findMany({ where: { active: true }, include: { category: true }, orderBy: [{ featured: 'desc' }, { createdAt: 'desc' }] });
  return NextResponse.json(products);
}
