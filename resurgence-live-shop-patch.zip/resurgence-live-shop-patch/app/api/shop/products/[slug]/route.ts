import { NextResponse } from 'next/server';
import { db } from '@/lib/shop/session';

export async function GET(_: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await db.shopProduct.findUnique({ where: { slug }, include: { category: true } });
  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json(product);
}
