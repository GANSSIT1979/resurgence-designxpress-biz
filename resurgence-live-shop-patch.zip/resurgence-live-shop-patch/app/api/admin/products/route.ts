import { NextResponse } from 'next/server';
import { db } from '@/lib/shop/session';

export async function GET() {
  return NextResponse.json(await db.shopProduct.findMany({ orderBy: { createdAt: 'desc' } }));
}

export async function POST(request: Request) {
  const form = await request.formData();
  const name = String(form.get('name') || '');
  const slug = String(form.get('slug') || '');
  const description = String(form.get('description') || '');
  const price = Number(form.get('price') || 0);
  const stock = Number(form.get('stock') || 0);
  await db.shopProduct.create({ data: { name, slug, description, price, stock, active: true } });
  return NextResponse.redirect(new URL('/admin/products', request.url));
}
