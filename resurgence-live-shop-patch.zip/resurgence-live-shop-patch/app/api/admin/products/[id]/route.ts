import { NextResponse } from 'next/server';
import { db } from '@/lib/shop/session';

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await request.json();
  const product = await db.shopProduct.update({ where: { id }, data: body });
  return NextResponse.json(product);
}
