import { NextResponse } from 'next/server';
import { db } from '@/lib/shop/session';

export async function GET() {
  return NextResponse.json(await db.shopOrder.findMany({ include: { user: true, items: true }, orderBy: { createdAt: 'desc' } }));
}
