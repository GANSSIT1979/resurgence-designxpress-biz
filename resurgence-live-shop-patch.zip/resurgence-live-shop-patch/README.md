# Resurgence Live Shop Patch

This package is a **direct file-path patch set** for the current Resurgence full-stack project.

## Included
- `prisma/schema.prisma` with commerce models added
- `prisma/seed.ts` extended with demo shop data
- `app/shop/*`
- `app/cart/page.tsx`
- `app/checkout/page.tsx`
- `app/account/orders/page.tsx`
- `app/admin/products/page.tsx`
- `app/admin/orders/page.tsx`
- `app/api/shop/*`
- `app/api/cart/*`
- `app/api/checkout/*`
- `app/api/admin/products/*`
- `app/api/admin/orders/*`
- `components/shop/*`
- `lib/shop/*`
- `public/branding/resurgence-logo.jpg`
- `.env.example`

## Merge Steps
1. Copy these files into your live Resurgence repository root.
2. Back up your current `prisma/schema.prisma` and `prisma/seed.ts`.
3. Run:
   - `npm install`
   - `npm run db:push`
   - `npm run db:seed`
4. Start the app with `npm run dev`.
5. Open:
   - `/shop`
   - `/cart`
   - `/checkout`
   - `/account/orders`
   - `/admin/products`
   - `/admin/orders`

## Demo Credentials
- Admin: `admin@resurgence.local / Admin123!`
- Customer: `customer@resurgence.local / Customer123!`

## Current Simplification
The shop module uses `customer@resurgence.local` as the active storefront user through `lib/shop/session.ts`.
Replace that file with your real auth/session lookup when you connect it to your existing login system.
