import bcrypt from "bcryptjs";
import {
  PrismaClient,
  Role,
  UserStatus,
  SubmissionStatus,
  SponsorStatus,
  PartnerStatus,
  PackageStatus,
  DeliverableStatus,
  InvoiceStatus,
  TransactionType,
  EmailQueueStatus,
  ShopPaymentMethod,
  ShopOrderStatus,
  ShopPaymentStatus,
} from "@prisma/client";

const db = new PrismaClient();

async function main() {
  await db.chatMessage.deleteMany();
  await db.chatConversation.deleteMany();
  await db.receipt.deleteMany();
  await db.cashierTransaction.deleteMany();
  await db.invoice.deleteMany();
  await db.notification.deleteMany();
  await db.emailQueue.deleteMany();
  await db.reportSnapshot.deleteMany();
  await db.sponsorDeliverable.deleteMany();
  await db.sponsorApplication.deleteMany();
  await db.sponsorProfile.deleteMany();
  await db.cartItem.deleteMany();
  await db.shopPayment.deleteMany();
  await db.shopOrderItem.deleteMany();
  await db.shopOrder.deleteMany();
  await db.shopAddress.deleteMany();
  await db.shopProduct.deleteMany();
  await db.shopCategory.deleteMany();
  await db.user.deleteMany();
  await db.sponsor.deleteMany();
  await db.partner.deleteMany();
  await db.sponsorInventoryItem.deleteMany();
  await db.galleryMedia.deleteMany();
  await db.mediaEvent.deleteMany();
  await db.creatorProfile.deleteMany();
  await db.productService.deleteMany();
  await db.contentSection.deleteMany();
  await db.setting.deleteMany();
  await db.sponsorPackage.deleteMany();
  await db.counter.deleteMany();

  const password = await bcrypt.hash("Admin123!", 10);
  const cashierPassword = await bcrypt.hash("Cashier123!", 10);
  const sponsorPassword = await bcrypt.hash("Sponsor123!", 10);
  const staffPassword = await bcrypt.hash("Staff123!", 10);
  const partnerPassword = await bcrypt.hash("Partner123!", 10);
  const customerPassword = await bcrypt.hash("Customer123!", 10);

  const supportingSponsor = await db.sponsorPackage.create({
    data: {
      title: "Supporting Sponsor",
      priceRange: "PHP 15,000–50,000",
      description: "Entry partnership tier for foundational brand visibility across RESURGENCE assets.",
      benefits: ["Logo placement", "Basic social mention", "Event acknowledgment"],
      deliverables: ["Poster placement", "1 creator mention", "Logo integration"],
      status: PackageStatus.ACTIVE,
      featured: false,
      sortOrder: 1,
    },
  });

  const officialBrandPartner = await db.sponsorPackage.create({
    data: {
      title: "Official Brand Partner",
      priceRange: "PHP 75,000–95,000",
      description: "Balanced visibility and creator support package for active brand campaigns.",
      benefits: ["Priority logo placement", "Creator feature", "On-ground mention"],
      deliverables: ["Digital integration", "Creator content package", "Sponsor feature block"],
      status: PackageStatus.ACTIVE,
      featured: true,
      sortOrder: 2,
    },
  });

  const majorPartner = await db.sponsorPackage.create({
    data: {
      title: "Major Partner",
      priceRange: "PHP 120,000–150,000",
      description: "High-value package for premium business exposure and integrated campaign delivery.",
      benefits: ["Premium exposure", "Multi-creator activations", "Inventory inclusion"],
      deliverables: ["Headline media slot", "Premium billing position", "Expanded sponsor assets"],
      status: PackageStatus.ACTIVE,
      featured: true,
      sortOrder: 3,
    },
  });

  await db.sponsorPackage.create({
    data: {
      title: "Event Presenting",
      priceRange: "Custom Proposal",
      description: "Custom presenting-tier event proposal for lead sponsor branding.",
      benefits: ["Naming rights potential", "Top billing", "Custom activation buildout"],
      deliverables: ["Custom proposal", "Executive planning", "Lead sponsor treatment"],
      status: PackageStatus.ACTIVE,
      featured: true,
      sortOrder: 4,
    },
  });

  const northline = await db.sponsor.create({
    data: {
      name: "Northline Nutrition",
      slug: "northline-nutrition",
      description: "Official nutrition partner focused on performance support and athlete recovery.",
      website: "https://example.com/northline",
      logo: "/branding/resurgence-logo.jpg",
      status: SponsorStatus.ACTIVE,
      packageId: officialBrandPartner.id,
    },
  });

  const partner = await db.partner.create({
    data: {
      name: "DesignXpress Premium Quality",
      slug: "designxpress-premium-quality",
      description: "Production and branding support partner for premium sports-business execution.",
      website: "https://designxpress.biz",
      logo: "/branding/resurgence-logo.jpg",
      status: PartnerStatus.ACTIVE,
    },
  });

  await db.sponsorProfile.create({
    data: {
      sponsorId: northline.id,
      packageId: officialBrandPartner.id,
      headline: "Performance-led nutrition support for RESURGENCE athletes",
      description: "Northline Nutrition powers high-performance basketball routines with sponsor-aligned athlete support programs.",
      contactName: "Northline Partnerships",
      contactEmail: "partnerships@northline.example",
      logo: "/branding/resurgence-logo.jpg",
    },
  });

  await db.creatorProfile.createMany({
    data: [
      {
        fullName: "Jake Anilao",
        slug: "jake-anilao",
        biography: "Jake Anilao is one of the public faces behind RESURGENCE Powered by DesignXpress.",
        journeyStory: "Jake leads creator-facing brand partnerships for RESURGENCE.",
        pointsPerGame: 19.4,
        assistsPerGame: 6.8,
        reboundsPerGame: 7.2,
        image: "/branding/resurgence-logo.jpg",
        socialLinks: { Facebook: "https://facebook.com" },
        featured: true,
      },
      {
        fullName: "Joshua Dollente",
        slug: "joshua-dollente",
        biography: "Joshua bridges entrepreneurship, player branding, and creator visibility.",
        journeyStory: "Joshua contributes creator energy and basketball identity to the RESURGENCE network.",
        pointsPerGame: 15.8,
        assistsPerGame: 4.9,
        reboundsPerGame: 4.6,
        image: "/branding/resurgence-logo.jpg",
        socialLinks: { Instagram: "https://instagram.com" },
        featured: true,
      },
    ],
  });

  await db.contentSection.createMany({
    data: [
      {
        key: "home-hero",
        title: "RESURGENCE Powered by DesignXpress",
        subtitle: "Sports-business sponsorship engine",
        body: "Premium sports-business branding and creator-driven sponsor activations.",
        ctaLabel: "Apply as Sponsor",
        ctaHref: "/sponsor/apply",
        active: true,
      },
      {
        key: "shop-hero",
        title: "RESURGENCE SHOP",
        subtitle: "Official merch and apparel",
        body: "Rise. Unite. Resurge. Shop official RESURGENCE merchandise.",
        ctaLabel: "Shop now",
        ctaHref: "/shop",
        active: true,
      },
    ],
  });

  await db.productService.createMany({
    data: [
      {
        title: "Sponsorship Strategy Packaging",
        slug: "sponsorship-strategy-packaging",
        description: "Package structuring and executive-ready commercial positioning.",
        image: "/branding/resurgence-logo.jpg",
        featured: true,
        priceLabel: "Custom Proposal",
        active: true,
      },
      {
        title: "Creator Network Activations",
        slug: "creator-network-activations",
        description: "Creator-led media activations built for basketball and brand visibility.",
        image: "/branding/resurgence-logo.jpg",
        featured: true,
        priceLabel: "Campaign Based",
        active: true,
      },
    ],
  });

  await db.setting.createMany({
    data: [
      { key: "companyBranding", value: "RESURGENCE Powered by DesignXpress" },
      { key: "adminContactData", value: "Jake Anilao | sponsorship@resurgence.designxpress.biz" },
      { key: "publicSiteDefaults", value: JSON.stringify({ followers: "2.15M+", activePlatforms: 2, creators: 6 }) },
      { key: "shopPaymentMethods", value: JSON.stringify(["COD", "GCASH_MANUAL", "BANK_TRANSFER"]) },
    ],
  });

  const admin = await db.user.create({ data: { name: "System Admin", email: "admin@resurgence.local", passwordHash: password, role: Role.SYSTEM_ADMIN, status: UserStatus.ACTIVE } });
  await db.user.create({ data: { name: "Cashier", email: "cashier@resurgence.local", passwordHash: cashierPassword, role: Role.CASHIER, status: UserStatus.ACTIVE } });
  await db.user.create({ data: { name: "Northline Sponsor", email: "sponsor@resurgence.local", passwordHash: sponsorPassword, role: Role.SPONSOR, status: UserStatus.ACTIVE, sponsorId: northline.id } });
  await db.user.create({ data: { name: "Staff User", email: "staff@resurgence.local", passwordHash: staffPassword, role: Role.STAFF, status: UserStatus.ACTIVE } });
  await db.user.create({ data: { name: "Partner User", email: "partner@resurgence.local", passwordHash: partnerPassword, role: Role.PARTNER, status: UserStatus.ACTIVE, partnerId: partner.id } });
  const customer = await db.user.create({ data: { name: "Juan Dela Cruz", email: "customer@resurgence.local", passwordHash: customerPassword, role: Role.CUSTOMER, status: UserStatus.ACTIVE } });

  const apparel = await db.shopCategory.create({ data: { name: "Apparel", slug: "apparel", description: "Official resurgence jerseys, hoodies and shirts." } });
  const accessories = await db.shopCategory.create({ data: { name: "Accessories", slug: "accessories", description: "Caps and lifestyle accessories." } });
  const drinkware = await db.shopCategory.create({ data: { name: "Drinkware", slug: "drinkware", description: "Tumblers and hydration gear." } });

  const jersey = await db.shopProduct.create({
    data: {
      name: "Resurgence Jersey",
      slug: "resurgence-jersey",
      sku: "RSG-JERSEY-25",
      description: "Official Resurgence jersey with premium breathable fabric.",
      shortDescription: "Game jersey",
      price: "1299",
      compareAtPrice: "1499",
      stock: 50,
      image: "/branding/resurgence-logo.jpg",
      active: true,
      featured: true,
      categoryId: apparel.id,
    },
  });

  const hoodie = await db.shopProduct.create({
    data: {
      name: "Resurgence Hoodie",
      slug: "resurgence-hoodie",
      sku: "RSG-HOODIE-01",
      description: "Official Resurgence hoodie for off-court wear.",
      shortDescription: "Warm-up hoodie",
      price: "1599",
      stock: 35,
      image: "/branding/resurgence-logo.jpg",
      active: true,
      featured: true,
      categoryId: apparel.id,
    },
  });

  const cap = await db.shopProduct.create({
    data: {
      name: "Resurgence Cap",
      slug: "resurgence-cap",
      sku: "RSG-CAP-01",
      description: "Official Resurgence cap.",
      shortDescription: "Cap",
      price: "499",
      stock: 100,
      image: "/branding/resurgence-logo.jpg",
      active: true,
      featured: true,
      categoryId: accessories.id,
    },
  });

  const tumbler = await db.shopProduct.create({
    data: {
      name: "Resurgence Tumbler",
      slug: "resurgence-tumbler",
      sku: "RSG-TUMBLER-01",
      description: "Official Resurgence tumbler.",
      shortDescription: "Tumbler",
      price: "399",
      stock: 60,
      image: "/branding/resurgence-logo.jpg",
      active: true,
      featured: false,
      categoryId: drinkware.id,
    },
  });

  const address = await db.shopAddress.create({
    data: {
      userId: customer.id,
      fullName: "Juan Dela Cruz",
      phone: "09123456789",
      line1: "123 Resurgence Street",
      city: "Manila",
      province: "Metro Manila",
      postalCode: "1000",
    },
  });

  const order = await db.shopOrder.create({
    data: {
      orderNumber: "RSG-000001",
      userId: customer.id,
      addressId: address.id,
      subtotal: "3397",
      shippingFee: "120",
      totalAmount: "3517",
      status: ShopOrderStatus.PAID,
      paymentStatus: ShopPaymentStatus.PAID,
      paymentMethod: ShopPaymentMethod.GCASH_MANUAL,
      notes: "Seeded order",
    },
  });

  await db.shopOrderItem.createMany({
    data: [
      { orderId: order.id, productId: jersey.id, productName: jersey.name, unitPrice: "1299", quantity: 1, totalPrice: "1299" },
      { orderId: order.id, productId: hoodie.id, productName: hoodie.name, unitPrice: "1599", quantity: 1, totalPrice: "1599" },
      { orderId: order.id, productId: cap.id, productName: cap.name, unitPrice: "499", quantity: 1, totalPrice: "499" },
    ],
  });

  await db.shopPayment.create({
    data: {
      orderId: order.id,
      amount: "3517",
      method: ShopPaymentMethod.GCASH_MANUAL,
      status: ShopPaymentStatus.PAID,
      referenceNumber: "GCASH-0001",
      proofImageUrl: "/branding/resurgence-logo.jpg",
    },
  });

  await db.notification.create({ data: { userId: admin.id, title: "Shop module seeded", message: "Commerce products, orders, and payments are now available." } });
  await db.emailQueue.create({ data: { toEmail: "customer@resurgence.local", subject: "Order confirmed", template: "shop_order_confirmed", payload: { orderNumber: "RSG-000001" }, status: EmailQueueStatus.PENDING, attempts: 0 } });
  await db.counter.createMany({ data: [{ scope: "invoice", value: 0 }, { scope: "receipt", value: 0 }] });

  console.log("Seed completed.");
  console.log("Demo admin: admin@resurgence.local / Admin123!");
  console.log("Demo customer: customer@resurgence.local / Customer123!");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
}).finally(async () => {
  await db.$disconnect();
});
