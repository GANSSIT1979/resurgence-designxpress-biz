import { db, getShopUser } from "./session";

export async function getCart() {
  const user = await getShopUser();
  const items = await db.cartItem.findMany({
    where: { userId: user.id },
    include: { product: true },
    orderBy: { createdAt: "desc" },
  });

  const subtotal = items.reduce((sum, item) => sum + Number(item.product.price) * item.quantity, 0);
  const shipping = items.length ? 120 : 0;
  const total = subtotal + shipping;

  return { user, items, subtotal, shipping, total };
}

export async function addToCart(productId: string, quantity = 1) {
  const user = await getShopUser();
  const existing = await db.cartItem.findUnique({ where: { userId_productId: { userId: user.id, productId } } });
  if (existing) {
    return db.cartItem.update({ where: { id: existing.id }, data: { quantity: existing.quantity + quantity } });
  }
  return db.cartItem.create({ data: { userId: user.id, productId, quantity } });
}

export async function updateCartItem(id: string, quantity: number) {
  if (quantity <= 0) {
    return db.cartItem.delete({ where: { id } });
  }
  return db.cartItem.update({ where: { id }, data: { quantity } });
}
