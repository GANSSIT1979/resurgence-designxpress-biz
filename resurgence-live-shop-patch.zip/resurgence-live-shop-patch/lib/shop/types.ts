export type CartLine = {
  id: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    image: string | null;
    stock: number;
  };
};

export type CheckoutPayload = {
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  province: string;
  postalCode?: string;
  paymentMethod: "COD" | "GCASH_MANUAL" | "BANK_TRANSFER";
  notes?: string;
};
