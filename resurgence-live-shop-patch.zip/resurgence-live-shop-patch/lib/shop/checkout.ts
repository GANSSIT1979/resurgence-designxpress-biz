import { ShopPaymentMethod, ShopPaymentStatus, ShopOrderStatus } from "@prisma/client";
import { db, getShopUser } from "./session";
import type { CheckoutPayload } from "./types";

export async function createOrder(payload: CheckoutPayload) {
  const { items, subtotal, shipping, total, user } = await (await import("./cart")).getCart();
  if (!items.length) throw new Error("Cart is empty");

  const address = await db.shopAddress.create({
    data: {
      userId: user.id,
      fullName: payload.fullName,
      phone: payload.phone,
      line1: payload.line1,
      line2: payload.line2,
      city: payload.city,
      province: payload.province,
      postalCode: payload.postalCode,
    },
  });

  const orderNumber = `RSG-${Date.now().toString().slice(-8)}`;
  const order = await db.shopOrder.create({
    data: {
      orderNumber,
      userId: user.id,
      addressId: address.id,
      subtotal,
      shippingFee: shipping,
      totalAmount: total,
      status: payload.paymentMethod === "COD" ? ShopOrderStatus.PROCESSING : ShopOrderStatus.AWAITING_PAYMENT,
      paymentStatus: payload.paymentMethod === "COD" ? ShopPaymentStatus.PENDING : ShopPaymentStatus.PENDING,
      paymentMethod: payload.paymentMethod as ShopPaymentMethod,
      notes: payload.notes,
    },
  });

  await db.shopOrderItem.createMany({
    data: items.map((item) => ({
      orderId: order.id,
      productId: item.productId,
      productName: item.product.name,
      unitPrice: item.product.price,
      quantity: item.quantity,
      totalPrice: Number(item.product.price) * item.quantity,
    })),
  });

  await db.shopPayment.create({
    data: {
      orderId: order.id,
      amount: total,
      method: payload.paymentMethod as ShopPaymentMethod,
      status: payload.paymentMethod === "COD" ? ShopPaymentStatus.PENDING : ShopPaymentStatus.PENDING,
    },
  });

  for (const item of items) {
    await db.shopProduct.update({ where: { id: item.productId }, data: { stock: { decrement: item.quantity } } });
  }
  await db.cartItem.deleteMany({ where: { userId: user.id } });
  return order;
}
