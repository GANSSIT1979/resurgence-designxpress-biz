import { PrismaClient } from "@prisma/client";

const db = globalThis.__shop_prisma ?? new PrismaClient();
if (process.env.NODE_ENV !== "production") (globalThis as any).__shop_prisma = db;

export async function getShopUser() {
  const email = process.env.SHOP_DEMO_EMAIL || "customer@resurgence.local";
  const user = await db.user.findUnique({ where: { email } });
  if (!user) throw new Error(`Missing demo shop user: ${email}`);
  return user;
}

export { db };
