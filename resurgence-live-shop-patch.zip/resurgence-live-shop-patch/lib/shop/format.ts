export function peso(value: number | string) {
  const amount = typeof value === "string" ? Number(value) : value;
  return new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" }).format(amount || 0);
}
